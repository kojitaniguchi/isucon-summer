``upper``
=========

The ``upper`` filter converts a value to uppercase:

.. code-block:: jinja

    {{ 'welcome'|upper }}

    {# outputs 'WELCOME' #}
