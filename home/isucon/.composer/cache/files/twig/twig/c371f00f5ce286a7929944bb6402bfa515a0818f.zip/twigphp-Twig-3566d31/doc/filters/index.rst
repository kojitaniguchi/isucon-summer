Filters
=======

.. toctree::
    :maxdepth: 1

    abs
    batch
    capitalize
    convert_encoding
    date
    date_modify
    default
    escape
    first
    format
    join
    json_encode
    keys
    last
    length
    lower
    merge
    nl2br
    number_format
    raw
    replace
    reverse
    round
    slice
    sort
    split
    striptags
    title
    trim
    upper
    url_encode
