# Slim example

1. Install composer

      ```text
      $ cd Slim
      $ composer install
      ```

2. Run php server

      ```text
      $ cd Slim
      $ php -S localhost:8888 -t example example/index.php
      ```

3. Open browser

      Open http://localhost:8888 in your browser and you will see 'Welcome to Slim!'
