#define UTS_RELEASE "4.4.0-91-generic"
#define UTS_UBUNTU_RELEASE_ABI 91
